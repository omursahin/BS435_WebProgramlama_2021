import React from "react";
import {Link} from 'react-router-dom';


export class Home extends React.Component {

    constructor(props) {
        super(props);
    }

    render() {
      return (
            <div>
                <h2>Movie List</h2>
                <Link to={"/create"}>
                    <button className="btn">New</button>
                </Link>

            </div>
        );
    }
}